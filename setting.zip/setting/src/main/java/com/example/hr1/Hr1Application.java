package com.example.hr1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hr1Application {

	public static void main(String[] args) {
		SpringApplication.run(Hr1Application.class, args);
	}

}
