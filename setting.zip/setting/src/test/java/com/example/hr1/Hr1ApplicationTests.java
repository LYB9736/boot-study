package com.example.hr1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hr1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
