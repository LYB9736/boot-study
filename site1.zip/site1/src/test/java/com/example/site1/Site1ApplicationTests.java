package com.example.site1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Site1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
